import train_model
import os

for test_img in os.listdir('test'):
    test_img_path = os.path.join('test',test_img)
    print(test_img,':',end='')
    for i in ['model1','model2','model3']:
        model = train_model.model(i,test_img_path)
        print(model,'|',end='')
    print()

'''
从下面的识别结果可以看到,有些字母例如：P、0、K、A识别很好，对于识别较差的数字，我们可以通过把未正确识别的数据，增加到训练数据来提高识别率。

0X65AWD.png :0I66BI8 |识别结果2 |识别结果3 |
700V.png :识别失败 |识别结果2 |识别结果3 |
CRAIG.png :B8AB |识别结果2 |识别结果3 |
DZ17YXR.png :0Z7YXB |识别结果2 |识别结果3 |
KA03MG2784.png :KA0BMB |识别结果2 |识别结果3 |
M771276.png :MZ727B |识别结果2 |识别结果3 |
P3RVP.png :PB8IP |识别结果2 |识别结果3 |
PGMN112.png :P0MNII2 |识别结果2 |识别结果3 |
TN21BZ0768.png :识别失败 |识别结果2 |识别结果3 |
'''